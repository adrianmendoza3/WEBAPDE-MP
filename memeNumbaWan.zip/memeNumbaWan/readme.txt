1. create mongodbdata folder
2. type in (outside folder) cmd "C:\Program Files\MongoDB\Server\3.6\bin\mongod.exe" --dbpath mongodbdata 
3. create mongodbcode folder
4. type inside mongodbcode folder cmd "npm init"
5. type inside mongodbcode folder cmd "npm i mongoose --save"

/Users/adrianmendoza/Documents/mongodb-osx-x86_64-enterprise-4.0.0/bin/mongod --dbpath mongodbdata